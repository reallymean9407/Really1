"use client";

import { useMemo, useState } from "react";
import { CalendarDays, ChevronRight, Search } from "lucide-react";

type Diary = { date: string; title: string; core?: string; insight?: string; reminder?: string };

const diaries: Diary[] = [
  { date: "2026. 6. 29", title: "미국 중간선거에 개입하기 시작하는 AI Money...!", core: "- 뉴욕 12선거구에서 규제완화(openAI) vs 규제강화(Anthropic) 구도가 정치 자금과 함께 부각\n- 유동성 긴축우려가 강해지면 AI 매출이 확실한 곳으로 돈이 몰림\n- 전세계 AI 매출이 데이터센터 감가상각 비용을 넘어서는 신호가 나타남", insight: "- 미국은 AI를 국가전략산업으로 바라보기 때문에 연방 차원의 단일 규칙은 빅테크와 AI 기업에게 유리\n- 지역별 AI 법안이 강화되면 데이터센터 인허가가 어려워질 수 있음\n- CapEx 부담은 작고 매출은 뚜렷한 반도체 회사 중심의 장세" },
  { date: "2026. 6. 30", title: "빠르게 커지는 우주 통신과 인공위성 산업 (ft. RKLB+IRDM)", core: "- 로켓랩과 이리듐 결합은 저궤도 네트워크와 위성통신 주파수의 가치가 핵심\n- 로켓랩은 발사, 위성 운영, 고객 서비스, 주파수까지 수직계열화\n- 이리듐의 높은 EBITDA와 구독 고객 기반은 방산 계약에도 유리", insight: "- 개인 소비자 스마트폰 시장보다 로봇, 방산, 항공 및 해안 안전용 통신 같은 틈새가 더 매력적일 수 있음", reminder: "- 다른 자산에 포모를 느끼기 전에 꾸준히 모으는 태도를 유지" },
  { date: "2026. 7. 1", title: "스테이블코인 발행사에서 유통사로 넘어가는 칼자루 (ft. Open USD)", core: "- 써클 경쟁사 오픈스탠다드 OUSD 등장\n- 발행사 단일 브랜드보다 어떤 브랜드가 성장해도 이득을 보는 인프라·유통 포지션이 합리적\n- 코인베이스는 써클과 오픈스탠다드 양쪽에 걸친 보험적 베팅", insight: "- 발행사 투자는 시장 확대 수혜와 마진율 하락 악재를 함께 따져야 함\n- 경쟁사 출현과 규제 지연은 단기 악재로 작용" },
  { date: "2026. 7. 2", title: "모 아니면 도, 빅테크 투자 축소의 신호탄 VS 하이퍼스케일러 경쟁 심화 (ft. META)", core: "- 메타가 연산력 판매와 네오클라우드 진출 가능성을 시사\n- 하이퍼스케일러 고객인 메모리와 기존 네오클라우드가 흔들림\n- 아직 연산력 부족 뉴스가 이어지고 있어 과잉투자로 판단하기엔 이름", insight: "- 메타가 시장 과잉을 믿었다면 신규 사업 진출을 노리지 않았을 가능성이 큼" },
  { date: "2026. 7. 3", title: "26년 하반기 투자 타임라인 점검", core: "- 시장이 상승만 바라보는 상태에서 콜옵션과 레버리지 전환이 늘어남\n- 빅테크 CapEx 축소를 시장은 기대하지만 실제 축소 전망은 뚜렷하지 않음", insight: "- 공매도는 상승장의 땔감이 될 수 있음\n- 닷컴버블 이후 시장은 충분한 우려를 안고 움직이고 있어 오히려 건강한 상승 가능성" },
  { date: "2026. 7. 16", title: "조정장에서 바라봐야 하는 것", core: "NeoCloud\n현재 네오클라우드 섹터는 AI 투자 수익성 의심으로 조정받지만 인프라 투자는 견고하게 이어질 전망. 본격적인 매출과 FCF 개선은 올해 말부터 내년 사이 확인될 가능성.\n\n양자\n방산과 소버린 AI 전략의 핵심 기술로 부각되며 정부 투자가 확대. 2~3년 장기 관점에서 다음 성장 사이클 후보.\n\n반도체·매크로\nTSMC 실적은 좋았지만 보수적 가이던스. ASML은 2027~2030년까지 반도체 공급 부족 가능성을 시사." },
  { date: "2026. 7. 23", title: "구글 실적발표, AI 내러티브를 이어주는 희생타?", core: "- 구글은 CapEx를 줄이지 않고 오히려 늘림\n- FCF가 처음으로 마이너스로 전환될 수 있는 흐름\n- 클라우드 매출과 영업이익은 강하게 성장했고 수주 잔고도 매우 큼\n- AI 연산 인프라 공급은 여전히 부족" },
  { date: "2026. 7. 23", title: "중간선거와 시장", core: "- AI 데이터센터와 관련 정책이 중간선거의 정치 쟁점으로 부상\n- 미중 AI 경쟁과 반도체 수출 통제는 초당적 사안, 데이터센터 전기요금·용수·환경 문제는 대립 이슈\n- 민주당 하원 장악 시 빅테크 견제와 청문회가 늘어날 수 있음\n\n중국 AI와 오픈소스\nKimi K3와 미국 모델 간 답변 유사성이 논란. 중국은 GPU와 데이터센터 부족으로 오픈소스 배포와 외부 네오클라우드 운영 구조를 활용.\n\n데이터센터\n하이퍼스케일러 자체 데이터센터는 2029~2030년 이후 본격 가동 전망. 그 전까지 네오클라우드가 공백을 메울 가능성이 큼." },
  { date: "2026. 7. 30", title: "하락장에서 다시 배우는 투자의 본질", core: "- 변동성이 큰 IREN 가격 추이를 통해 시장 반응을 참고\n- 내러티브와 펀더멘탈이 맞아도 레버리지가 쌓이면 하락과 연쇄청산에 취약\n- 공포탐욕지수는 Fear 영역이나 정크본드 수요는 Greed로 경기 침체 확률을 낮게 볼 수 있는 단서\n- 부자가 되는 투자보다 부자로 사는 투자 원칙을 점검" },
  { date: "2026. 8. 3", title: "일본 환율을 살려야 미국이 사는 이유 (ft. 베센트 재무장관과 장기금리)", core: "- 연준이 장기금리를 통한 시장 긴축을 용인하면서 장기금리 관리의 공은 재무부로 이동\n- 미국과 일본이 엔화 방어 개입에 나서며 미국채 시장 안정도 함께 노림\n- AI 기업 채권 발행이 미국채 수요를 일부 빼앗는 구조\n- 베센트는 엔화 숏 투자자의 손익비를 나쁘게 만드는 심리전을 주도" },
  { date: "2026. 8. 4", title: "프론티어 VS 오픈소스 AI 경쟁의 최고 수혜자는? (ft. 팔란티어 실적발표)", core: "- 팔란티어 실적은 매출과 EPS 모두 예상치를 상회\n- 오픈소스와 프론티어 경쟁은 AI 사용량 전체를 늘릴 수 있음\n- 하이브리드 시나리오에서는 보안 소프트웨어, 전력 생산 솔루션, 네오클라우드, 엔비디아가 수혜" },
  { date: "2026. 8. 7", title: "네오클라우드 숏을 선언한 마이클 버리 (ft. ORCL, NBIS)", core: "- 마이클 버리가 오라클과 네비우스 숏 포지션을 공개\n- 논리는 대차대조표 밖 GPU 구매 약정, 장기 임대 계약, 전력 계약 등 숨은 부채 우려\n- 네비우스 주가가 크게 흔들림" },
  { date: "2026. 8. 10", title: "워렌 버핏은 롱, 마이클 버리는 숏, 누가 맞을까? (ft. 장기금리)", core: "- 스페이스X는 락업해제 우려에도 급상승\n- 우주 섹터는 장기금리에 민감하지만 장기금리 상방이 일부 막혔다는 인식\n- 버크셔 해서웨이는 2022년 이후 처음으로 현금 보유액이 줄고 주식 순매수 전환\n- AI 섹터의 가장 큰 병목은 자본", insight: "- 시장이 한쪽으로 몰리면 오히려 반대로 움직이는 모습을 경계" },
  { date: "2026. 8. 11", title: "첫번째 시험대에 오른 베센트의 금리 안정화 (ft. 로켓랩 실적발표)", core: "- 엔화와 미국 10년물 금리가 다시 움직이며 재무부 대응이 시험대에 오름\n- 로켓랩은 뉴트론 발사 일정, 이리듐 인수, GHOST 기술 발표가 핵심\n- 엔비디아는 블랙록·블랙스톤·KKR 등과 AI 인프라 금융 플랫폼 구상" },
  { date: "2026. 8. 12", title: "실적발표 시즌의 주인공으로 떠오르는 네오클라우드 섹터 (CRWV, NBIS 실적발표)", core: "- 코어위브는 매출과 적자폭 개선, 백로그 확대를 보여줌\n- 네비우스는 매출 성장, 계약 전력 용량 상향, 선급금 조건 개선이 부각\n- 일부 용량을 남겨두며 더 좋은 계약 조건을 기다리는 전략\n- Core CPI가 예상에 부합하며 금리 인상 확률 하락" },
  { date: "2026. 8. 14", title: "시타델이 인정한 역대급 실적 시즌, AI 수익성이 높아지는 이유", core: "- 기술주 이익 성장 속도가 빨라 Forward P/E 부담이 줄어드는 흐름\n- MW당 매출이 코로케이션보다 네오클라우드에서 훨씬 높음\n- IREN Horizon 1 인도는 수직계열화 전략의 속도를 보여줌\n- 기관투자자 비중과 AI 매출 비중이 높아지며 변동성 안정 기대" },
  { date: "2026. 8. 17", title: "빅테크급 매출을 넘보는 앤스로픽, IPO 시장 영향은?", core: "- 앤스로픽 IPO 가능성과 매출 규모가 AI 인프라 섹터에 중요\n- 오픈AI와 앤스로픽 매출 성장은 하이퍼스케일러와 네오클라우드 시장 규모를 좌우\n- 이미 Too Big To Fail 단계에 가까워졌다는 판단\n- 상장 이후 락업 일정에 맞춘 분할 진입 아이디어" },
  { date: "2026. 8. 18", title: "AI 성장 내러티브 VS 장기금리 우려 내러티브, 대응 전략은? (ft. 투자학개론 예약판매!)", core: "- 미국 30년물 장기금리가 금융위기 초기 수준에 접근\n- 장기금리 상승은 미국만이 아니라 일본·유럽에서도 공통적으로 나타남\n- 해결책은 재정지출 축소, AI 채권 발행 둔화, 연준 장기채 매입, 재무부 장기채 발행 축소 등이지만 모두 쉽지 않음\n- 고금리 환경에서는 성장성이 확실한 AI 클라우드와 현금 창출력 좋은 메모리가 상대적으로 부각될 수 있음" },
  { date: "2026. 8. 20", title: "다시 시작된 트럼프의 리딩방? (ft. 비트코인)", core: "- 미국 재무부가 장기국채 매입 규모를 2배로 늘렸다는 소식\n- 장기채 공급 감소는 장기금리 관리에 유용\n- 단기채 수요는 스테이블코인 발행사가 받쳐줄 수 있음\n- 중간선거 전까지 비트코인과 이더리움 상승 내러티브가 이어질 가능성" },
  { date: "2026. 8. 21", title: "비트코인이랑 장기금리 누르는 거랑 무슨 상관이지? (ft. 베센트)", core: "- 재무부 바이백 선언은 장기금리의 심리적 상단을 확인시킨 이벤트\n- 정부가 장기금리 상승을 억제하면 채권 보유자의 실질 구매력 우려가 커짐\n- 자본 일부가 금과 비트코인 같은 비화폐 자산으로 이동할 수 있음\n- 장기채 숏보다 금/비트코인 롱이 구현 방식이 될 수 있음" },
  { date: "2026. 8. 24", title: "연준의 포워드 가이던스 역할을 대신하려는 재무부? (ft. 엔비디아)", core: "- 베센트 재무장관의 이란 제재 기자회견은 전쟁 마무리 신호로 해석 가능\n- 엔비디아 실적 전 가격 결정력과 AI 서버 칩 가격 인상이 핵심\n- 클라우드 기업도 원가 상승분을 전가할 수 있는지 확인이 중요\n- 재무부가 연준의 포워드 가이던스 역할을 일부 대신하는 모습" },
  { date: "2026. 8. 25", title: "유동성 완화 카드를 꺼내든 재무부, 꿈틀대는 비트코인", core: "- 재무부가 TGA 일부를 활용해 고금리 국채를 바이백할 수 있다는 소식\n- 실제 개입은 유동성 측면에서 상당한 효과 가능\n- 시장은 정부 개입에 대한 불확실성에 적응하는 과정\n- 이란과 거래하는 기관에 대한 강한 경제제재도 발표" },
  { date: "2026. 8. 26", title: "아이렌 실적발표, 무엇을 기대하고 무엇을 기대하지 않을지?", core: "- IREN 회계연도 실적 전 신규 AI 고객 계약, Horizon 1 인도, 자금조달 현황이 관전 포인트\n- GPU 담보대출, 전환사채, 고객 선급금, 데이터센터 담보금융의 조합이 중요\n- 미란티스 인수 이후 시너지와 엔비디아 협업 지속 여부를 확인" },
  { date: "2026. 8. 27", title: "젠슨 황: AI, 변곡점을 넘었다. 버블의 수명을 늘리는 엔비디아", core: "- 엔비디아 실적은 매출, 데이터센터 매출, 가이던스 모두 강한 성장\n- ACIE와 하이퍼스케일러 매출이 성장 견인\n- 엔비디아 DSX 클라우드와 제3자 자본 조달 플랫폼은 AI 인프라 금융을 확장\n- GPU 자산의 경제적 수명과 잔존가치 논리가 중요" },
  { date: "2026. 8. 28", title: "호재 활용을 잘 하는 것도 능력이다...! (아이렌 실적발표)", core: "- IREN 매출에서 AI 매출이 전분기 대비 두 배로 성장\n- 프론티어 AI 랩과 중장기 계약, MW당 단가 상승, Contracted ARR과 Operating ARR이 핵심\n- 고객 선급금과 GPU 금융이 CapEx 조달 구조를 보강\n- Capital Flywheel을 얼마나 효율적으로 운영하는지가 핵심 과제" },
  { date: "2026. 8. 29", title: "예상보다 금리 인상에 적극적이었던 케빈 워시의 잭슨홀 연설 분석", core: "- 케빈 워시는 AI와 생산성 증가, 포워드 가이던스의 한계, 통화정책 원칙을 강조\n- 시장이 스스로 데이터를 보고 리스크를 판단하길 원한다는 방향\n- 물가 안정에 대한 더 확실한 지표가 필요하다는 매파적 뉘앙스\n- 베센트 재무장관의 흐름을 따라가는 전략이 합리적이라는 판단" },
];

function parseDate(input: string) {
  const match = input.match(/(\d{2,4})[./]\s*(\d{1,2})[./]\s*(\d{1,2})/);
  if (!match) return new Date(input);
  const year = Number(match[1].length === 2 ? `20${match[1]}` : match[1]);
  return new Date(year, Number(match[2]) - 1, Number(match[3]));
}

function weekOfMonth(date: Date) {
  return Math.ceil((date.getDate() + new Date(date.getFullYear(), date.getMonth(), 1).getDay()) / 7);
}

function formatMonth(date: Date) {
  return `${date.getFullYear()}년 ${date.getMonth() + 1}월`;
}

function formatWeek(date: Date) {
  return `${weekOfMonth(date)}주차`;
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [activeMonth, setActiveMonth] = useState<string | null>(null);
  const [activeWeek, setActiveWeek] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState(diaries.length - 1);

  const grouped = useMemo(() => {
    const filtered = diaries
      .map((diary, index) => ({ ...diary, index }))
      .filter((diary) => `${diary.date} ${diary.title} ${diary.core ?? ""} ${diary.insight ?? ""} ${diary.reminder ?? ""}`.toLowerCase().includes(query.toLowerCase()));
    return filtered.reduce<Record<string, Record<string, (Diary & { index: number })[]>>>((acc, diary) => {
      const date = parseDate(diary.date);
      const month = formatMonth(date);
      const week = formatWeek(date);
      acc[month] ??= {};
      acc[month][week] ??= [];
      acc[month][week].push(diary);
      return acc;
    }, {});
  }, [query]);

  const months = Object.keys(grouped);
  const selected = diaries[activeIndex] ?? diaries[diaries.length - 1];
  const selectedDate = parseDate(selected.date);

  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <section className="border-b border-black/10 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-8 md:px-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-sm font-semibold text-[var(--accent-strong)]">김정민_자산 관리 테이블 · 투자일기 정리</p>
              <h1 className="mt-2 text-3xl font-bold md:text-5xl">세상학개론 투자일기 정리</h1>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="rounded-md border border-black/10 bg-[var(--muted)] px-4 py-3"><p className="text-2xl font-bold">{diaries.length}</p><p className="text-xs text-[var(--muted-foreground)]">일기</p></div>
              <div className="rounded-md border border-black/10 bg-[var(--muted)] px-4 py-3"><p className="text-2xl font-bold">{new Set(diaries.map((d) => formatMonth(parseDate(d.date)))).size}</p><p className="text-xs text-[var(--muted-foreground)]">개월</p></div>
              <div className="rounded-md border border-black/10 bg-[var(--muted)] px-4 py-3"><p className="text-2xl font-bold">3</p><p className="text-xs text-[var(--muted-foreground)]">단계 탐색</p></div>
            </div>
          </div>
          <label className="flex max-w-xl items-center gap-3 rounded-md border border-black/10 bg-[var(--surface)] px-4 py-3">
            <Search className="h-5 w-5 text-[var(--muted-foreground)]" />
            <input value={query} onChange={(event) => setQuery(event.target.value)} className="w-full bg-transparent text-sm outline-none" placeholder="제목, 키워드, 본문 검색" />
          </label>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-5 px-5 py-6 md:grid-cols-[380px_minmax(0,1fr)] md:px-8">
        <nav className="rounded-md border border-black/10 bg-white p-3 shadow-sm">
          <div className="mb-3 flex items-center gap-2 px-2 py-1 text-sm font-semibold">
            <CalendarDays className="h-4 w-4 text-[var(--accent-strong)]" />
            월별 → 주별 → 일별
          </div>
          <div className="space-y-2">
            {months.map((month) => {
              const isMonthOpen = activeMonth === month || (!activeMonth && month === months[months.length - 1]);
              const weeks = Object.keys(grouped[month]);
              return (
                <div key={month} className="rounded-md border border-black/10">
                  <button className="flex w-full items-center justify-between px-3 py-3 text-left font-semibold" onClick={() => { setActiveMonth(isMonthOpen ? null : month); setActiveWeek(null); }}>
                    <span>{month}</span><span className="text-sm text-[var(--muted-foreground)]">{Object.values(grouped[month]).flat().length}개</span>
                  </button>
                  {isMonthOpen && (
                    <div className="border-t border-black/10 bg-[var(--muted)] p-2">
                      {weeks.map((week) => {
                        const weekKey = `${month}-${week}`;
                        const isWeekOpen = activeWeek === weekKey || (!activeWeek && month === months[months.length - 1] && week === weeks[weeks.length - 1]);
                        return (
                          <div key={weekKey} className="mb-2 rounded-md bg-white">
                            <button className="flex w-full items-center justify-between px-3 py-2 text-sm font-semibold" onClick={() => setActiveWeek(isWeekOpen ? null : weekKey)}>
                              <span>{week}</span><ChevronRight className={`h-4 w-4 transition ${isWeekOpen ? "rotate-90" : ""}`} />
                            </button>
                            {isWeekOpen && (
                              <div className="space-y-1 px-2 pb-2">
                                {grouped[month][week].map((diary) => (
                                  <button key={`${diary.index}-${diary.title}`} onClick={() => setActiveIndex(diary.index)} className={`w-full rounded-md px-3 py-2 text-left text-sm transition ${activeIndex === diary.index ? "bg-[var(--accent)] text-[var(--accent-foreground)]" : "hover:bg-[var(--muted)]"}`}>
                                    <span className="block font-semibold">{diary.date}</span>
                                    <span className="line-clamp-2 text-xs opacity-80">{diary.title}</span>
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </nav>

        <article className="rounded-md border border-black/10 bg-white shadow-sm">
          <div className="border-b border-black/10 p-5 md:p-7">
            <p className="text-sm font-semibold text-[var(--accent-strong)]">{formatMonth(selectedDate)} · {formatWeek(selectedDate)} · {selected.date}</p>
            <h2 className="mt-2 text-2xl font-bold md:text-4xl">{selected.title}</h2>
          </div>
          <div className="grid gap-4 p-5 md:p-7">
            {[
              ["핵심 내용", selected.core],
              ["인사이트 배우기", selected.insight],
              ["다시 한번 더 상기", selected.reminder],
            ].map(([label, body]) => body ? (
              <section key={label} className="rounded-md border border-black/10 bg-[var(--paper)] p-4">
                <h3 className="mb-3 text-sm font-bold text-[var(--accent-strong)]">{label}</h3>
                <p className="whitespace-pre-wrap text-[15px] leading-7">{body}</p>
              </section>
            ) : null)}
          </div>
        </article>
      </section>
    </main>
  );
}
